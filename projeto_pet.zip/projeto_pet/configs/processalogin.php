<?php
include_once 'configs/login.php';
$l = new login ($_POST['login'],$_POST['senha']);

