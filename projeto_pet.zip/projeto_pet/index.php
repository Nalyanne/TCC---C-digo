<html >
<title>Petshop</title>
<head>
<meta http-equiv="Content-Type" content="text/html;" charset="utf-8" />
<link rel="stylesheet" type="text/css" href="estilo.css" />
<head>
<body><div id="tudo">
	<div id="login">
	<p>
	<img src="imagens/foto3.jpg" width="170px" height="170px" border="1px"  />
	<p>Insira seu dados:
	<form action="configs/processalogin.php" method = "POST">
	
		Login:<input type="text" name="login" /><br>
		Senha:<input type="text" name="senha" /><br>
		<p><input type="submit" value="Logar" />
		<a href="#" Esqueceu sua senha? />
		
	</form>
	</div>
</div>
</body>
</html>